from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status

from .models import Book
from .serializers import BookListSerializer, BookSerializer

# Create your views here.
@api_view(['GET'])
def library_list(request):
	if request.method == "GET":
		libraries = Book.objects.all()
		serializer = BookListSerializer(libraries, many=True)
		return Response(serializer.data)

@api_view(['GET'])
def library_detail(request, library_pk):
	library = Book.objects.get(pk=library_pk)
	if request.method == "GET":
		serializer = BookSerializer(library)
		return Response(serializer.data)
