from rest_framework import serializers
from .models import Book

# 제목 필드만 제공
class BookListSerializer(serializers.ModelSerializer):
	class Meta:
		model = Book
		fields = ("title",)

# 모든 정보 제공
class BookSerializer(serializers.ModelSerializer):
	class Meta:
		model = Book
		fields = "__all__"