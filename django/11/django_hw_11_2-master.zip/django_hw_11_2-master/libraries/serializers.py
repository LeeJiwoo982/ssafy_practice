from rest_framework import serializers
from .models import Book, Review


class BookListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Book
        fields = ('title', )

class BookSerializer(serializers.ModelSerializer):

    class Meta:
        model = Book
        fields = '__all__'

# 리뷰 전체 조회 기능 담당
# 일부 필드만
class ReviewListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Review
        fields = ('content', 'score', )

# 리뷰 모든 필드 가공
class ReviewSerializer(serializers.ModelSerializer):

    class Meta:
        model = Review
        fields = '__all__'
        read_only_fields = ('book', )