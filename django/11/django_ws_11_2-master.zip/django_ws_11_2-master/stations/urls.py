from django.urls import path
from . import views

urlpatterns = [
	path('locations/', views.location_create),	# 생성
	path('locations/<int:location_pk>/stations/', views.station_create), # 충전소 생성
	path('stations/', views.station_list),	# 전체 목록 조회, 
	path('stations/<int:station_pk>/', views.station_detail),	# 상세 정보 조회
]
