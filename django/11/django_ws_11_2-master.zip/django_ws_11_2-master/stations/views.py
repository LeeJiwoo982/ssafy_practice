from django.shortcuts import render, get_object_or_404

from rest_framework.response import Response
from rest_framework.decorators import api_view

from .models import Location, Station, Car
from .serializers import (
	LocationSerializer, 
	StationListSerializer,
	StationSerializer,
)

# Create your views here.
# 지역 생성
@api_view(['POST'])
def location_create(request):
	if request.method == 'POST':
		serializer = LocationSerializer(data=request.data)
		if serializer.is_valid(raise_exception=True):
			serializer.save()
			return Response(serializer.data)

# 충전소 생성
@api_view(['POST'])
def station_create(request, location_pk):
	address = Location.objects.get(pk=location_pk)
	if request.method == 'POST':
		serializer = StationSerializer(data=request.data)
		if serializer.is_valid(raise_exception=True):
			serializer.save(address=address)
			return Response(serializer.data)
		
# 전체 조회
@api_view(['GET'])
def station_list(request):
	stations = Station.objects.all()
	if request.method == 'GET':
		serializer = StationListSerializer(stations, many=True)
		return Response(serializer.data)


@api_view(['GET'])
def station_detail(request, station_pk):
	station = get_object_or_404(Station, pk=station_pk)
	if request.method == 'GET':
		serializer = StationSerializer(station)
		return Response(serializer.data)