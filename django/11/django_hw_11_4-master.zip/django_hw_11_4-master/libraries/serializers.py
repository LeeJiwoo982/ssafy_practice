from rest_framework import serializers
from .models import Book, Review

# 도서 전체 조회
# 제목만
class BookListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Book
        fields = ('title', )


# 도서 정보
# 모든 필드 제공
# 도서에 참조하는 리뷰 정보 제공
# 역참조 중인 리뷰의 총 수 제공
class BookSerializer(serializers.ModelSerializer):
    # review_set에 활용할 리뷰데이터 가공하는 도구
    class ReviewDetailSerializer(serializers.ModelSerializer):
        class Meta:
            model = Review
            fields = ('content', 'score', )
    
    # 기존의 역참조 매니저 덮어쓰기
    # 읽기 전용, N인거라 다수 댓글 출력 가능하게
    review_set = ReviewDetailSerializer(read_only=True, many=True)

    # 읽기 전용 새로운 필드 생성
    # 리뷰 개수를 구한다.
    num_of_reviews = serializers.SerializerMethodField()

    class Meta:
        model = Book
        fields = '__all__'

    # 리뷰 개수 구하는 함수. 변환만 하는걸 권장한다고...
    def get_num_of_reviews(self, obj):
        return obj.num_of_reviews


# 리뷰 전체 조회
# 내용, 점수만
# 리뷰가 참조하는 도서의 isbn의 정보를 제공하기
class ReviewListSerializer(serializers.ModelSerializer):
    class BookIsbnSerializer(serializers.ModelSerializer):
        class Meta:
            model = Book
            fields = ('isbn', )
    
    book = BookIsbnSerializer(read_only=True)

    class Meta:
        model = Review
        fields = '__all__'


# 리뷰 모든 정보
# class ReviewSerializer(serializers.ModelSerializer):

#     class Meta:
#         model = Review
#         fields = '__all__'
#         read_only_fields = ('book',)