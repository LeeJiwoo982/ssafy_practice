<template>
  <div>
    <h1>AboutView</h1>
  </div>
</template>

<script setup>
</script>
