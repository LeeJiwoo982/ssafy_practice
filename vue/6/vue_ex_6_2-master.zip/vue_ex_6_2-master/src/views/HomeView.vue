<template>
  <div>
    <h1>HomeView</h1>
  </div>
</template>

<script setup>
</script>
