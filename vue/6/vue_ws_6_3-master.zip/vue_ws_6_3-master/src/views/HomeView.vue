<template>
  <div class="main-page">
    <!-- 화면 구성 -->
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>
