<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <header>
    <div class="wrapper">
      <nav>
        <RouterLink to="/">
          <button>Home</button>
        </RouterLink> | 
        <RouterLink to="/accounts/signup/">
          <button>SignUp</button>
        </RouterLink> | 
        <RouterLink to="/accounts/login/">
          <button>SignIn</button>
        </RouterLink>
      </nav>
    </div>
  </header>

  <RouterView />
</template>

<style scoped>
</style>
