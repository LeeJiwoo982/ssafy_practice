<script setup>
</script>

<template>
</template>

<style scoped>
div {
  border: 1px solid #ccc;
  padding: 10px;
  margin-top: 10px;
}
h3 {
  font-size: 18px;
}
p {
  font-size: 14px;
}
</style>
