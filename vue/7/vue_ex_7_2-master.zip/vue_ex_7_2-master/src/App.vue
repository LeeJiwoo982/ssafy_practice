<template>
  <div>
    <ProductList />
  </div>
</template>

<script setup>
import ProductList from '@/components/ProductList.vue'
</script>

<style scoped>
</style>
