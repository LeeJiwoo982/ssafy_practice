<template>
  <div>
    <Notice />
    <ProductList />
  </div>
</template>

<script setup>
import ProductList from '@/components/ProductList.vue'
import Notice from '@/components/Notice.vue'
</script>

<style scoped>
</style>
