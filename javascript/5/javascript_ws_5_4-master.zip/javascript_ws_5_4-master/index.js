/* 
  아래에 코드를 작성해주세요.
*/
// 검색창, 버튼 마크업
const searchInput = document.querySelector('.search-box__input')
const searchBtn = document.querySelector('.search-box__button')
const resultContainer = document.querySelector('.search-result')
const loadingList = document.querySelector('.search-result--loadingList')


searchBtn.addEventListener('click', () => {
  const keyword = searchInput.ariaValueMax.trim()

  if (!keyword) {
    alert("검색어를 입력해주세요")
    return;
  }

  loadingList.style.display = 'block'
  resultContainer.style.display = 'none'

  fetchAlbums(keyword)
})

const fetchAlbums = function () {
  axios({
    
  })
}