# articles/models.py
from django.db import models
