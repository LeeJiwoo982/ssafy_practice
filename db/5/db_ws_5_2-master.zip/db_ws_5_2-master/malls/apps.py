from django.apps import AppConfig


class MallsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'malls'
